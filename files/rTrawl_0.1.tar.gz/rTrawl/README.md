# rTrawl
simulation and estimation of trawl processes
